import Link from "@/components/site/site-link";
import { ArrowUpRight, Route, CarFront, Users, HeartHandshake } from "@/components/site/icons";
import type { NavigationItem } from "@/lib/luzik-navigation";

const icons = { car: CarFront, bike: Route, help: HeartHandshake, school: Users };

export function NavigationGroups({ item, pathname, onNavigate }: {
  item: NavigationItem;
  pathname?: string;
  onNavigate?: () => void;
}) {
  const groups = item.groups ?? [{ label: "Poznaj Luzik", icon: "school" as const, links: item.children ?? [] }];

  return <div className="luzik-nav-groups">
    {groups.map(group => {
      const Icon = icons[group.icon];
      return <section key={group.label} className="luzik-nav-group">
        <h3>{group.label}</h3>
        <ul>
          {group.links.map(link => <li key={link.href}>
            <Link href={link.href} onClick={onNavigate} aria-current={pathname === link.href ? "page" : undefined} className="luzik-nav-card">
              <span className="luzik-nav-card-icon"><Icon size={20} aria-hidden="true" /></span>
              <span className="luzik-nav-card-copy"><strong>{link.label}</strong>{link.description && <span>{link.description}</span>}</span>
              <ArrowUpRight size={15} className="luzik-nav-card-arrow" aria-hidden="true" />
            </Link>
          </li>)}
        </ul>
      </section>;
    })}
  </div>;
}
